using System.Text.Json;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using Azure.Data.Tables;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using AzureFunctionAppRetail.Models;

namespace AzureFunctionAppRetail
{
    public class TableStorageFunction
    {
        private readonly TableServiceClient _tableServiceClient;
        private readonly ILogger _logger;

        public TableStorageFunction(TableServiceClient tableServiceClient, ILoggerFactory loggerFactory)
        {
            _tableServiceClient = tableServiceClient;
            _logger = loggerFactory.CreateLogger<TableStorageFunction>();
        }

        [Function("AddCustomer")]
        public async Task<HttpResponseData> AddCustomer([HttpTrigger(AuthorizationLevel.Anonymous, "post")] HttpRequestData req)
        {
            var body = await new StreamReader(req.Body).ReadToEndAsync();
            var customer = JsonSerializer.Deserialize<Customer>(body);

            var tableClient = _tableServiceClient.GetTableClient("Customer");
            await tableClient.CreateIfNotExistsAsync();
            await tableClient.AddEntityAsync(customer);

            _logger.LogInformation("Added new customer: {FirstName} {LastName}", customer.FirstName, customer.LastName);

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            await response.WriteStringAsync("Customer added successfully");
            return response;
        }

        [Function("GetCustomers")]
        public async Task<HttpResponseData> GetCustomers([HttpTrigger(AuthorizationLevel.Anonymous, "get")] HttpRequestData req)
        {
            var tableClient = _tableServiceClient.GetTableClient("Customer");
            var customers = new List<Customer>();

            await foreach (var customer in tableClient.QueryAsync<Customer>())
            {
                customers.Add(customer);
            }

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "application/json");
            await response.WriteStringAsync(JsonSerializer.Serialize(customers));
            return response;
        }

        [Function("SearchCustomers")]
        public async Task<HttpResponseData> SearchCustomers([HttpTrigger(AuthorizationLevel.Anonymous, "get")] HttpRequestData req)
        {
            var query = System.Web.HttpUtility.ParseQueryString(req.Url.Query);
            var searchTerm = query["searchTerm"];

            var tableClient = _tableServiceClient.GetTableClient("Customer");
            var customers = new List<Customer>();

            await foreach (var customer in tableClient.QueryAsync<Customer>())
            {
                if ((customer.FirstName.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                     customer.LastName.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                     customer.Email.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)))
                {
                    customers.Add(customer);
                }
            }

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "application/json");
            await response.WriteStringAsync(JsonSerializer.Serialize(customers));
            return response;
        }
    }
}