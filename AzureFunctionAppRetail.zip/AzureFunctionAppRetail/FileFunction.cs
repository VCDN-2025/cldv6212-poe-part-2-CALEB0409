using System.Text.Json;
using System.IO;
using System.Threading.Tasks;
using Azure.Storage.Files.Shares;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace AzureFunctionAppRetail
{
    public class FileFunction
    {
        private readonly ShareServiceClient _shareServiceClient;
        private readonly ILogger _logger;

        public FileFunction(ShareServiceClient shareServiceClient, ILoggerFactory loggerFactory)
        {
            _shareServiceClient = shareServiceClient;
            _logger = loggerFactory.CreateLogger<FileFunction>();
        }

        [Function("UploadFile")]
        public async Task<HttpResponseData> UploadFile([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            var requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var uploadRequest = JsonSerializer.Deserialize<JsonElement>(requestBody);

            var shareName = uploadRequest.GetProperty("ShareName").GetString();
            var directoryName = uploadRequest.GetProperty("DirectoryName").GetString();
            var fileName = uploadRequest.GetProperty("FileName").GetString();
            var fileContent = uploadRequest.GetProperty("FileContent").GetString();

            var shareClient = _shareServiceClient.GetShareClient(shareName);
            await shareClient.CreateIfNotExistsAsync();

            var directoryClient = shareClient.GetDirectoryClient(directoryName);
            await directoryClient.CreateIfNotExistsAsync();

            var fileBytes = Convert.FromBase64String(fileContent);
            var fileClient = directoryClient.GetFileClient(fileName);

            await fileClient.CreateAsync(fileBytes.Length);
            await fileClient.UploadRangeAsync(new Azure.HttpRange(0, fileBytes.Length), new MemoryStream(fileBytes));

            _logger.LogInformation("Uploaded file '{fileName}' to share '{shareName}/{directoryName}'", fileName, shareName, directoryName);

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            await response.WriteStringAsync("File uploaded successfully");
            return response;
        }

        [Function("ListFiles")]
        public async Task<HttpResponseData> ListFiles([HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequestData req)
        {
            var query = System.Web.HttpUtility.ParseQueryString(req.Url.Query);
            var shareName = query["shareName"];
            var directoryName = query["directoryName"];

            var shareClient = _shareServiceClient.GetShareClient(shareName);
            var directoryClient = shareClient.GetDirectoryClient(directoryName);

            var files = new List<string>();
            await foreach (var fileItem in directoryClient.GetFilesAndDirectoriesAsync())
            {
                files.Add(fileItem.Name);
            }

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "application/json");
            await response.WriteStringAsync(JsonSerializer.Serialize(files));

            return response;
        }
    }
}