using System.Text.Json;
using System.IO;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace AzureFunctionAppRetail
{
    public class BlobStorageFunction
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly ILogger _logger;

        public BlobStorageFunction(BlobServiceClient blobServiceClient, ILoggerFactory loggerFactory)
        {
            _blobServiceClient = blobServiceClient;
            _logger = loggerFactory.CreateLogger<BlobStorageFunction>();
        }

        [Function("UploadBlob")]
        public async Task<HttpResponseData> UploadBlob([HttpTrigger(AuthorizationLevel.Anonymous, "post")] HttpRequestData req)
        {
            var requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var uploadRequest = JsonSerializer.Deserialize<JsonElement>(requestBody);

            var containerName = uploadRequest.GetProperty("ContainerName").GetString();
            var fileName = uploadRequest.GetProperty("FileName").GetString();
            var fileContent = uploadRequest.GetProperty("FileContent").GetString();

            var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
            await containerClient.CreateIfNotExistsAsync();

            var blobClient = containerClient.GetBlobClient(fileName);
            var fileBytes = Convert.FromBase64String(fileContent);

            using var stream = new MemoryStream(fileBytes);
            await blobClient.UploadAsync(stream, overwrite: true);

            var response = req.CreateResponse(System.Net.HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "application/json");
            await response.WriteStringAsync(JsonSerializer.Serialize(new { BlobUrl = blobClient.Uri.ToString() }));

            _logger.LogInformation("Uploaded blob '{fileName}' to container '{containerName}'", fileName, containerName);

            return response;
        }
    }
}
