using System.Text.Json;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using Azure;
using Azure.Data.Tables;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using AzureFunctionAppRetail.Models;
using System.Net;

namespace AzureFunctionAppRetail
{
    public class TableStorageFunction
    {
        private readonly TableServiceClient _tableServiceClient;
        private readonly ILogger _logger;
        private const string TableName = "Customer";

        public TableStorageFunction(TableServiceClient tableServiceClient, ILoggerFactory loggerFactory)
        {
            _tableServiceClient = tableServiceClient;
            _logger = loggerFactory.CreateLogger<TableStorageFunction>();
        }

        [Function(nameof(AddCustomer))]
        public async Task<HttpResponseData> AddCustomer(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "AddCustomer")] HttpRequestData req)
        {
            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var customer = JsonSerializer.Deserialize<Customer>(requestBody);

                if (customer == null || string.IsNullOrEmpty(customer.Email))
                {
                    return await CreateResponse(req, HttpStatusCode.BadRequest, "Invalid customer data");
                }

                var tableClient = _tableServiceClient.GetTableClient(TableName);
                await tableClient.CreateIfNotExistsAsync();
                
                // Set default values if not provided
                customer.PartitionKey = "CUSTOMER";
                if (string.IsNullOrEmpty(customer.RowKey))
                {
                    customer.RowKey = Guid.NewGuid().ToString();
                }

                await tableClient.AddEntityAsync(customer);

                _logger.LogInformation("Added new customer: {FirstName} {LastName}", customer.FirstName, customer.LastName);
                
                var response = req.CreateResponse(HttpStatusCode.Created);
                await response.WriteAsJsonAsync(new { id = customer.RowKey, message = "Customer added successfully" });
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding customer");
                return await CreateResponse(req, HttpStatusCode.InternalServerError, "Error adding customer");
            }
        }

        [Function(nameof(GetCustomers))]
        public async Task<HttpResponseData> GetCustomers(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "GetCustomers")] HttpRequestData req)
        {
            try
            {
                var tableClient = _tableServiceClient.GetTableClient(TableName);
                var customers = new List<Customer>();

                await foreach (var customer in tableClient.QueryAsync<Customer>(c => c.PartitionKey == "CUSTOMER"))
                {
                    customers.Add(customer);
                }

                var response = req.CreateResponse(HttpStatusCode.OK);
                response.Headers.Add("Content-Type", "application/json");
                await response.WriteAsJsonAsync(customers);
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving customers");
                return await CreateResponse(req, HttpStatusCode.InternalServerError, "Error retrieving customers");
            }
        }

        private async Task<HttpResponseData> CreateResponse(HttpRequestData req, HttpStatusCode statusCode, string message)
        {
            var response = req.CreateResponse(statusCode);
            response.Headers.Add("Content-Type", "application/json");
            await response.WriteAsJsonAsync(new { message = message });
            return response;
        }
    }
}